//
//  HomeViewController.swift
//  MobileDetector
//
//  Created by Mykhailo Melnychuk on 11/15/19.
//  Copyright © 2019 Mykhailo Melnychuk. All rights reserved.
//

import UIKit
import CoreML
import Vision

enum ModelType{
    case mobilenet
    case densenet
    case none

    var title: String {
        switch self {
        case .mobilenet: return "MobileNet"
        case .densenet: return "DenseNet"
        default:
            return "None"
        }
    }

    var model: MLModel? {
        switch self {
        case .mobilenet: return EyeMobileNet3().model
        case .densenet: return DenseNet121().model
        default:
            return nil
        }
    }
}

class HomeViewController: UIViewController {
    @IBOutlet weak private var photo_image_view: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var predictionLabel: UILabel!

    private var selectedModelType = ModelType.none
}

extension HomeViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true)
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            fatalError("couldn't load image from Photos")
        }

        guard let newImage = ImagePreprocessing.preprocess(image: image) else {
            fatalError("couldn't preprocess image")
        }

        photo_image_view.image = newImage

        guard let ciImage = CIImage(image: newImage) else {
            fatalError("couldn't convert UIImage to CIImage")
        }

        detectScene(image: ciImage)
    }
}

private extension HomeViewController {
    @IBAction func predictButtonPressed(_ sender: UIButton) {
        let actionSheet = UIAlertController(title: "Choose model", message: nil, preferredStyle: .actionSheet)

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
            actionSheet.dismiss(animated: true, completion: nil)
        }

        let denseNetAction = UIAlertAction(title: "DenseNet", style: .default) { [weak self] (_) in
            self?.selectedModelType = .densenet
            actionSheet.dismiss(animated: false, completion: nil)
            self?.showImagePicker()
        }

        let mobileNetAction = UIAlertAction(title: "MobileNetV3", style: .default) { [weak self] (_) in
            self?.selectedModelType = .densenet
            actionSheet.dismiss(animated: false, completion: nil)
            self?.showImagePicker()
        }

        actionSheet.addAction(mobileNetAction)
        actionSheet.addAction(denseNetAction)
        actionSheet.addAction(cancelAction)

        present(actionSheet, animated: true, completion: nil)
    }


    func showImagePicker() {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .savedPhotosAlbum
        present(pickerController, animated: true)
    }

    func detectScene(image: CIImage) {
        do {
            guard let selectedModel = selectedModelType.model else {
                fatalError("Model init failed")
            }

            let model = try VNCoreMLModel(for: selectedModel)

            Predictor.predict(image: image, model: model) { [weak self] (time, output) in
                DispatchQueue.main.async {
                    self?.timeLabel.text = String(time)

                    self?.predictionLabel.text = String(output.description)

                }
            }
        } catch {
            print("Error info: \(error)")
        }
    }
}
