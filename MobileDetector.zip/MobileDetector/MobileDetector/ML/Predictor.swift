//
//  Predictor.swift
//  MobileDetector
//
//  Created by Mykhailo Melnychuk on 11/15/19.
//  Copyright © 2019 Mykhailo Melnychuk. All rights reserved.
//

import CoreML
import Vision

class Predictor {
    static func predict(image: CIImage,
                        model: VNCoreMLModel,
                        completion: @escaping ((_ time: Double, _ prediction: MLFeatureValue)->())) {
        let startTime = CFAbsoluteTimeGetCurrent()

        let request = VNCoreMLRequest(model: model) { rrequest, error in

            guard let results = rrequest.results as? [VNCoreMLFeatureValueObservation],
                let topResult = results.first else {

                    fatalError("unexpected result type from VNCoreMLRequest")
            }

            let timeElapsed = CFAbsoluteTimeGetCurrent() - startTime
            completion(timeElapsed, topResult.featureValue)
        }


        let handler = VNImageRequestHandler(ciImage: image)
        DispatchQueue.global(qos: .userInteractive).async {
            do {
                try handler.perform([request])
            } catch {
                print(error)
            }
        }
    }
}
